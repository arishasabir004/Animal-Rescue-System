# D:\ANIMALRESCUE\database\__init__.py
from .db_connection import DatabaseConnection
from .animal_queries import AnimalQueries
from .adoption_queries import AdoptionQueries
from .shelter_queries import ShelterQueries    # NEW
from .volunteer_queries import VolunteerQueries # NEW

__all__ = [
    'DatabaseConnection',
    'AnimalQueries',
    'AdoptionQueries',
    'ShelterQueries',   # NEW
    'VolunteerQueries'  # NEW
]