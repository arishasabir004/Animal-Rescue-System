import mysql.connector
from mysql.connector import Error
import config # This imports the config.py module from the project root

class DatabaseConnection:
    def __init__(self):
        self.connection = None

    def __enter__(self):
        try:
            # Access DB_CONFIG from the imported config module
            self.connection = mysql.connector.connect(**config.DB_CONFIG)
            return self.connection
        except Error as e:
            print(f"Error connecting to MySQL: {e}")
            # Do NOT re-raise if you want the app to handle gracefully
            # For now, re-raise to see if connection is the core issue
            raise

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.connection and self.connection.is_connected():
            self.connection.close()