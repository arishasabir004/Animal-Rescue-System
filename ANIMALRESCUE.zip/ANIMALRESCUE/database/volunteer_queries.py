# D:\ANIMALRESCUE\database\volunteer_queries.py

from .db_connection import DatabaseConnection

class VolunteerQueries:
    @staticmethod
    def get_all_volunteers():
        with DatabaseConnection() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT * FROM volunteer")
            return cursor.fetchall()

    @staticmethod
    def get_volunteer_by_id(volunteer_id):
        with DatabaseConnection() as conn:
            cursor = conn.cursor(dictionary=True)
            # ADD THIS NEW PRINT STATEMENT *EXACTLY* HERE:
            print(f"--- DEBUGGING volunteer_queries.py ---")
            print(f"Attempting to execute query: SELECT * FROM volunteer WHERE volunteer_id = %s with ID: {volunteer_id}")
            print(f"--- END DEBUGGING volunteer_queries.py ---")
            cursor.execute("SELECT * FROM volunteer WHERE volunteer_id = %s", (volunteer_id,))
            return cursor.fetchone()

    @staticmethod
    def add_volunteer(volunteer_data):
        with DatabaseConnection() as conn:
            cursor = conn.cursor()
            query = """
                INSERT INTO volunteer
                (first_name, last_name, email, phone, join_date)
                VALUES (%s, %s, %s, %s, %s)
            """
            cursor.execute(query, (
                volunteer_data['first_name'],
                volunteer_data['last_name'],
                volunteer_data['email'],
                volunteer_data['phone'],
                volunteer_data['join_date']
            ))
            conn.commit()
            return cursor.lastrowid

    @staticmethod
    def update_volunteer(volunteer_id, volunteer_data):
        with DatabaseConnection() as conn:
            cursor = conn.cursor()
            query = """
                UPDATE volunteer SET
                first_name = %s, last_name = %s, email = %s, phone = %s, join_date = %s
                WHERE volunteer_id = %s
            """
            cursor.execute(query, (
                volunteer_data['first_name'],
                volunteer_data['last_name'],
                volunteer_data['email'],
                volunteer_data['phone'],
                volunteer_data['join_date'],
                volunteer_id
            ))
            conn.commit()
            return cursor.rowcount

    @staticmethod
    def delete_volunteer(volunteer_id):
        with DatabaseConnection() as conn:
            cursor = conn.cursor()
            try:
                # Delete dependent records from volunteer_assignment
                delete_assignments_query = "DELETE FROM volunteer_assignment WHERE volunteer_id = %s"
                cursor.execute(delete_assignments_query, (volunteer_id,))
                conn.commit()

                # Delete the volunteer record
                delete_volunteer_query = "DELETE FROM volunteer WHERE volunteer_id = %s"
                cursor.execute(delete_volunteer_query, (volunteer_id,))
                conn.commit()

                print(f"Volunteer with ID {volunteer_id} and associated assignments deleted successfully.")
                return cursor.rowcount
            except Exception as e:
                conn.rollback()
                print(f"Error deleting volunteer {volunteer_id}: {e}")
                raise e