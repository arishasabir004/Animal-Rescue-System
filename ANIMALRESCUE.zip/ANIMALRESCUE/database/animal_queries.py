# D:\ANIMALRESCUE\database\animal_queries.py

from .db_connection import DatabaseConnection

class AnimalQueries:
    @staticmethod
    def get_all_animals():
        with DatabaseConnection() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT * FROM animal")
            return cursor.fetchall()

    @staticmethod
    def get_animal_by_id(animal_id):
        with DatabaseConnection() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT * FROM animal WHERE animalid = %s", (animal_id,))
            return cursor.fetchone()

    @staticmethod
    def get_available_animals():
        with DatabaseConnection() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT * FROM animal WHERE Status = 'Available'")
            return cursor.fetchall()

    @staticmethod
    def add_animal(animal_data):
        with DatabaseConnection() as conn:
            cursor = conn.cursor()
            query = """
                INSERT INTO animal
                (Name, Species, Breed, Age, Gender, RescueDate, Status)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """
            cursor.execute(query, (
                animal_data['name'],
                animal_data['species'],
                animal_data['breed'],
                animal_data['age'],
                animal_data['gender'],
                animal_data['rescue_date'],
                animal_data['status']
            ))
            conn.commit()
            return cursor.lastrowid

    @staticmethod
    def update_animal(animal_id, animal_data):
        with DatabaseConnection() as conn:
            cursor = conn.cursor()
            query = """
                UPDATE animal SET
                Name = %s, Species = %s, Breed = %s, Age = %s,
                Gender = %s, RescueDate = %s, Status = %s
                WHERE animalid = %s
            """
            cursor.execute(query, (
                animal_data['name'],
                animal_data['species'],
                animal_data['breed'],
                animal_data['age'],
                animal_data['gender'],
                animal_data['rescue_date'],
                animal_data['status'],
                animal_id
            ))
            conn.commit()
            return cursor.rowcount

    @staticmethod
    def delete_animal(animal_id):
        with DatabaseConnection() as conn:
            # Use a dictionary cursor for SELECT queries where you access results by column name.
            # The same cursor can be used for subsequent DML operations like DELETE.
            cursor = conn.cursor(dictionary=True) # <--- IMPORTANT CHANGE HERE

            try:
                # Get shelter_ids associated with this animal_id.
                # This is crucial because `donation` might reference `shelter_id`
                # which in turn is linked to this animal.
                get_shelter_ids_query = "SELECT shelter_id FROM shelter WHERE animalid = %s"
                cursor.execute(get_shelter_ids_query, (animal_id,))
                shelter_ids_result = cursor.fetchall()
                # Now 'row' will be a dictionary, so row['shelter_id'] is valid.
                shelter_ids = [row['shelter_id'] for row in shelter_ids_result] if shelter_ids_result else []

                # 1. Delete dependent records from `donation`
                #    Delete donations directly linked to the animal
                delete_donations_by_animal_query = "DELETE FROM donation WHERE animalid = %s"
                cursor.execute(delete_donations_by_animal_query, (animal_id,))
                conn.commit()

                #    Delete donations linked to shelters associated with this animal
                if shelter_ids:
                    # Create a string of placeholders for the IN clause
                    placeholders = ','.join(['%s'] * len(shelter_ids))
                    delete_donations_by_shelter_query = f"DELETE FROM donation WHERE shelter_id IN ({placeholders})"
                    cursor.execute(delete_donations_by_shelter_query, tuple(shelter_ids))
                    conn.commit()

                # 2. Delete dependent records from `shelter`
                delete_shelters_query = "DELETE FROM shelter WHERE animalid = %s"
                cursor.execute(delete_shelters_query, (animal_id,))
                conn.commit()

                # 3. Delete dependent records from `animal_rescue`
                delete_animal_rescue_query = "DELETE FROM animal_rescue WHERE animalid = %s"
                cursor.execute(delete_animal_rescue_query, (animal_id,))
                conn.commit()

                # 4. Delete dependent records from `adoption`
                delete_adoptions_query = "DELETE FROM adoption WHERE animalid = %s"
                cursor.execute(delete_adoptions_query, (animal_id,))
                conn.commit()

                # 5. Now delete the animal record itself
                delete_animal_query = "DELETE FROM animal WHERE animalid = %s"
                cursor.execute(delete_animal_query, (animal_id,))
                conn.commit()

                print(f"Animal with ID {animal_id} and all associated records deleted successfully.")
                return cursor.rowcount
            except Exception as e:
                conn.rollback()
                print(f"Error deleting animal {animal_id}: {e}")
                raise e