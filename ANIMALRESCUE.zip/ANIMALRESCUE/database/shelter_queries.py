# D:\ANIMALRESCUE\database\shelter_queries.py
from .db_connection import DatabaseConnection

class ShelterQueries:
    @staticmethod
    def get_all_shelters():
        with DatabaseConnection() as conn:
            cursor = conn.cursor(dictionary=True)
            cursor.execute("SELECT * FROM shelter")
            return cursor.fetchall()

    @staticmethod
    def get_shelter_by_id(shelter_id):
        with DatabaseConnection() as conn:
            cursor = conn.cursor(dictionary=True)
            # ADD THIS NEW PRINT STATEMENT *EXACTLY* HERE:
            print(f"--- DEBUGGING shelter_queries.py ---")
            print(f"Attempting to execute query: SELECT * FROM shelter WHERE shelter_id = %s with ID: {shelter_id}")
            print(f"--- END DEBUGGING shelter_queries.py ---")
            cursor.execute("SELECT * FROM shelter WHERE shelter_id = %s", (shelter_id,)) # <--- ENSURE THIS IS shelter_id
            return cursor.fetchone()

    @staticmethod
    def add_shelter(shelter_data):
        with DatabaseConnection() as conn:
            cursor = conn.cursor()
            query = """
                INSERT INTO shelter
                (shelter_name, address, city, phone_number, capacity, animalid)
                VALUES (%s, %s, %s, %s, %s, %s)
            """
            cursor.execute(query, (
                shelter_data['shelter_name'],  # Changed from 'name' to 'shelter_name'
                shelter_data['address'],
                shelter_data['city'],
                shelter_data['phone_number'],
                shelter_data['capacity'],
                shelter_data['animalid']
            ))
            conn.commit()
            return cursor.lastrowid

    @staticmethod
    def update_shelter(shelter_id, shelter_data):
        with DatabaseConnection() as conn:
            cursor = conn.cursor()
            query = """
                UPDATE shelter SET
                shelter_name = %s, address = %s, city = %s, phone_number = %s, capacity = %s, animalid = %s
                WHERE shelter_id = %s
            """
            cursor.execute(query, (
                shelter_data['shelter_name'],  # Changed from 'name' to 'shelter_name'
                shelter_data['address'],
                shelter_data['city'],
                shelter_data['phone_number'],
                shelter_data['capacity'],
                shelter_data['animalid'],
                shelter_id
            ))
            conn.commit()
            return cursor.rowcount

    @staticmethod
    def delete_shelter(shelter_id):
        with DatabaseConnection() as conn:
            cursor = conn.cursor()
            try:
                # Delete dependent records from `donation` table first
                # because `donation` has a foreign key referencing `shelter_id`.
                delete_donations_query = "DELETE FROM donation WHERE shelter_id = %s"
                cursor.execute(delete_donations_query, (shelter_id,))
                conn.commit()

                # Now delete the shelter record itself.
                delete_shelter_query = "DELETE FROM shelter WHERE shelter_id = %s"
                cursor.execute(delete_shelter_query, (shelter_id,))
                conn.commit()

                print(f"Shelter with ID {shelter_id} and associated donations deleted successfully.")
                return cursor.rowcount
            except Exception as e:
                conn.rollback()
                print(f"Error deleting shelter {shelter_id}: {e}")
                raise e


