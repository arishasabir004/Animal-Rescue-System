# D:\ANIMALRESCUE\database\adoption_queries.py
from .db_connection import DatabaseConnection # <-- THIS MUST BE A RELATIVE IMPORT

class AdoptionQueries:
    @staticmethod
    def get_all_adoptions():
        with DatabaseConnection() as conn:
            cursor = conn.cursor(dictionary=True)
            query = """
                SELECT a.*, an.Name as animal_name, an.Species
                FROM adoption a
                JOIN animal an ON a.animalid = an.animalid
            """
            cursor.execute(query)
            return cursor.fetchall()

    @staticmethod
    def get_adoption_by_id(adoption_id):
        with DatabaseConnection() as conn:
            cursor = conn.cursor(dictionary=True)
            query = """
                SELECT a.*, an.Name as animal_name, an.Species
                FROM adoption a
                JOIN animal an ON a.animalid = an.animalid
                WHERE a.adoption_id = %s
            """
            cursor.execute(query, (adoption_id,))
            return cursor.fetchone()

    @staticmethod
    def add_adoption(adoption_data):
        with DatabaseConnection() as conn:
            cursor = conn.cursor()
            query = """
                INSERT INTO adoption
                (animalid, adopter_name, adopter_email, adoption_date)
                VALUES (%s, %s, %s, %s)
            """
            cursor.execute(query, (
                adoption_data['animal_id'],
                adoption_data['adopter_name'],
                adoption_data['adopter_email'],
                adoption_data['adoption_date']
            ))
            conn.commit()

            # Update animal status to 'Adopted'
            update_query = "UPDATE animal SET Status = 'Adopted' WHERE animalid = %s"
            cursor.execute(update_query, (adoption_data['animal_id'],))
            conn.commit()

            return cursor.lastrowid

    @staticmethod
    def delete_adoption(adoption_id):
        with DatabaseConnection() as conn:
            cursor = conn.cursor()
            try:
                # Get animal ID before deletion to update its status back to 'Available'
                query = "SELECT animalid FROM adoption WHERE adoption_id = %s"
                cursor.execute(query, (adoption_id,))
                result = cursor.fetchone()
                animal_id = result[0] if result else None # Access by index as cursor is not dictionary=True

                # Delete adoption record
                delete_adoption_query = "DELETE FROM adoption WHERE adoption_id = %s"
                cursor.execute(delete_adoption_query, (adoption_id,))
                conn.commit()

                # Update animal status back to 'Available' if an animal was associated
                if animal_id:
                    update_animal_status_query = "UPDATE animal SET Status = 'Available' WHERE animalid = %s"
                    cursor.execute(update_animal_status_query, (animal_id,))
                    conn.commit()

                print(f"Adoption record {adoption_id} deleted and animal status updated successfully.")
                return cursor.rowcount
            except Exception as e:
                conn.rollback()
                print(f"Error deleting adoption {adoption_id}: {e}")
                raise e
