import sys
from pathlib import Path

# --- Flask Imports ---
from flask import Flask, render_template, request, redirect, url_for, flash

# --- Add project directory to Python path ---
# This ensures that 'database' package can be found
sys.path.insert(0, str(Path(__file__).parent))

# --- Database Module Imports (using aliases for clarity and robustness) ---
import database.db_connection as db_conn_module
import database.animal_queries as animal_q_module
import database.adoption_queries as adoption_q_module
import database.shelter_queries as shelter_q_module
import database.volunteer_queries as volunteer_q_module

# --- Flask App Initialization ---
app = Flask(__name__)
app.secret_key = 'your-secret-key-here'  # IMPORTANT: Change this to a strong, random key for production

# --- Main Routes ---

@app.route('/')
def index():
    """Renders the home page."""
    return render_template('index.html')

# --- Animal Routes ---

@app.route('/animals')
def animals():
    """Displays a list of all animals."""
    animals_data = animal_q_module.AnimalQueries.get_all_animals()
    return render_template('animals.html', animals=animals_data)

@app.route('/add_animal', methods=['GET', 'POST'])
def add_animal():
    """Handles adding a new animal."""
    if request.method == 'POST':
        try:
            animal_data = {
                'name': request.form['name'],
                'species': request.form['species'],
                'breed': request.form['breed'],
                'age': int(request.form['age']),
                'gender': request.form['gender'],
                'rescue_date': request.form['rescue_date'],
                'status': request.form['status']
            }
            animal_q_module.AnimalQueries.add_animal(animal_data)
            flash('Animal added successfully!', 'success')
            return redirect(url_for('animals'))
        except Exception as e:
            flash(f'Error adding animal: {str(e)}', 'danger')
    return render_template('add_animal.html')

@app.route('/edit_animal/<int:animal_id>', methods=['GET', 'POST'])
def edit_animal(animal_id):
    """Handles editing an existing animal."""
    animal = animal_q_module.AnimalQueries.get_animal_by_id(animal_id)
    if not animal:
        flash('Animal not found!', 'danger')
        return redirect(url_for('animals'))

    if request.method == 'POST':
        try:
            updated_data = {
                'name': request.form['name'],
                'species': request.form['species'],
                'breed': request.form['breed'],
                'age': int(request.form['age']),
                'gender': request.form['gender'],
                'rescue_date': request.form['rescue_date'],
                'status': request.form['status']
            }
            animal_q_module.AnimalQueries.update_animal(animal_id, updated_data)
            flash('Animal updated successfully!', 'success')
            return redirect(url_for('animals'))
        except Exception as e:
            flash(f'Error updating animal: {str(e)}', 'danger')

    return render_template('edit_animal.html', animal=animal)

@app.route('/delete_animal/<int:animal_id>')
def delete_animal(animal_id):
    """Handles deleting an animal."""
    try:
        animal_q_module.AnimalQueries.delete_animal(animal_id)
        flash('Animal deleted successfully!', 'success')
    except Exception as e:
        flash(f'Error deleting animal: {str(e)}', 'danger')
    return redirect(url_for('animals'))

# --- Adoption Routes ---

@app.route('/adoptions')
def adoptions():
    """Displays a list of all adoption records."""
    adoptions_data = adoption_q_module.AdoptionQueries.get_all_adoptions()
    return render_template('adoptions.html', adoptions=adoptions_data)

@app.route('/add_adoption', methods=['GET', 'POST'])
def add_adoption():
    """Handles recording a new adoption."""
    if request.method == 'POST':
        try:
            adoption_data = {
                'animal_id': int(request.form['animal_id']),
                'adopter_name': request.form['adopter_name'],
                'adopter_email': request.form['adopter_email'],
                'adoption_date': request.form['adoption_date']
            }
            adoption_q_module.AdoptionQueries.add_adoption(adoption_data)
            flash('Adoption recorded successfully!', 'success')
            return redirect(url_for('adoptions'))
        except Exception as e:
            flash(f'Error recording adoption: {str(e)}', 'danger')

    # Fetch available animals to populate the dropdown in the adoption form
    available_animals = animal_q_module.AnimalQueries.get_available_animals()
    return render_template('add_adoption.html', animals=available_animals)

@app.route('/delete_adoption/<int:adoption_id>')
def delete_adoption(adoption_id):
    """Handles deleting an adoption record."""
    try:
        adoption_q_module.AdoptionQueries.delete_adoption(adoption_id)
        flash('Adoption cancelled successfully!', 'success')
    except Exception as e:
        flash(f'Error cancelling adoption: {str(e)}', 'danger')
    return redirect(url_for('adoptions'))

# --- Shelter Routes ---

@app.route('/shelters')
def shelters():
    """Displays a list of all shelters."""
    shelters_data = shelter_q_module.ShelterQueries.get_all_shelters()
    return render_template('shelters.html', shelters=shelters_data)

@app.route('/add_shelter', methods=['GET', 'POST'])
def add_shelter():
    """Handles adding a new shelter."""
    if request.method == 'POST':
        try:
            shelter_data = {
                'shelter_name': request.form['name'],
                'address': request.form['address'],
                'city': request.form['city'],
                'phone_number': request.form['phone_number'],
                'capacity': int(request.form['capacity']),
                'animalid': int(request.form['animalid']) if request.form['animalid'] else None
            }
            shelter_q_module.ShelterQueries.add_shelter(shelter_data)
            flash('Shelter added successfully!', 'success')
            return redirect(url_for('shelters'))
        except Exception as e:
            flash(f'Error adding shelter: {str(e)}', 'danger')
    return render_template('add_shelter.html')

@app.route('/edit_shelter/<int:shelter_id>', methods=['GET', 'POST'])
def edit_shelter(shelter_id):
    """Handles editing an existing shelter."""
    shelter = shelter_q_module.ShelterQueries.get_shelter_by_id(shelter_id)
    if not shelter:
        flash('Shelter not found!', 'danger')
        return redirect(url_for('shelters'))

    if request.method == 'POST':
        try:
            shelter_data = {
                'shelter_name': request.form['name'],
                'address': request.form['address'],
                'city': request.form['city'],
                'phone_number': request.form['phone_number'],
                'capacity': int(request.form['capacity']),
                'animalid': int(request.form['animalid']) if request.form['animalid'] else None
            }
            shelter_q_module.ShelterQueries.update_shelter(shelter_id, shelter_data)
            flash('Shelter updated successfully!', 'success')
            return redirect(url_for('shelters'))
        except Exception as e:
            flash(f'Error updating shelter: {str(e)}', 'danger')
    return render_template('edit_shelter.html', shelter=shelter)

@app.route('/delete_shelter/<int:shelter_id>')
def delete_shelter(shelter_id):
    """Handles deleting a shelter."""
    try:
        shelter_q_module.ShelterQueries.delete_shelter(shelter_id)
        flash('Shelter deleted successfully!', 'success')
    except Exception as e:
        flash(f'Error deleting shelter: {str(e)}', 'danger')
    return redirect(url_for('shelters'))

# --- Volunteer Routes ---

@app.route('/volunteers')
def volunteers():
    """Displays a list of all volunteers."""
    volunteers_data = volunteer_q_module.VolunteerQueries.get_all_volunteers()
    return render_template('volunteers.html', volunteers=volunteers_data)

@app.route('/add_volunteer', methods=['GET', 'POST'])
def add_volunteer():
    """Handles adding a new volunteer."""
    if request.method == 'POST':
        try:
            volunteer_data = {
                'first_name': request.form['first_name'],
                'last_name': request.form['last_name'],
                'email': request.form['email'],
                'phone': request.form['phone'],
                'join_date': request.form['join_date']
            }
            volunteer_q_module.VolunteerQueries.add_volunteer(volunteer_data)
            flash('Volunteer added successfully!', 'success')
            return redirect(url_for('volunteers'))
        except Exception as e:
            flash(f'Error adding volunteer: {str(e)}', 'danger')
    return render_template('add_volunteer.html')

@app.route('/edit_volunteer/<int:volunteer_id>', methods=['GET', 'POST'])
def edit_volunteer(volunteer_id):
    """Handles editing an existing volunteer."""
    volunteer = volunteer_q_module.VolunteerQueries.get_volunteer_by_id(volunteer_id)
    if not volunteer:
        flash('Volunteer not found!', 'danger')
        return redirect(url_for('volunteers'))

    if request.method == 'POST':
        try:
            volunteer_data = {
                'first_name': request.form['first_name'],
                'last_name': request.form['last_name'],
                'email': request.form['email'],
                'phone': request.form['phone'],
                'join_date': request.form['join_date']
            }
            volunteer_q_module.VolunteerQueries.update_volunteer(volunteer_id, volunteer_data)
            flash('Volunteer updated successfully!', 'success')
            return redirect(url_for('volunteers'))
        except Exception as e:
            flash(f'Error updating volunteer: {str(e)}', 'danger')
    return render_template('edit_volunteer.html', volunteer=volunteer)

@app.route('/delete_volunteer/<int:volunteer_id>')
def delete_volunteer(volunteer_id):
    """Handles deleting a volunteer."""
    try:
        volunteer_q_module.VolunteerQueries.delete_volunteer(volunteer_id)
        flash('Volunteer deleted successfully!', 'success')
    except Exception as e:
        flash(f'Error deleting volunteer: {str(e)}', 'danger')
    return redirect(url_for('volunteers'))

# --- Application Entry Point ---
if __name__ == '__main__':
    app.run(debug=True)
