DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '#Cheeno434',  # IMPORTANT: Replace with your actual MySQL password
    'database': 'animalrescue'
}

# App configuration
class Config:
    SECRET_KEY = 'your-secret-key-here'  # IMPORTANT: Change this to a strong, random key for production
    TEMPLATES_AUTO_RELOAD = True